
def create_list(n):
  ret = []
  for x in range(0,n):
    ret.append(x)
  print(ret)
  return ret