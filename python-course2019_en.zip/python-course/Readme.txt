Python - An Introduction

With this course we want to give an introduction into the programming language Python and its application. This is explicitly not a course to learn programming: we assume that you already have experience with other programming languages. Furthermore it is not about developing complex software in Python - in our opinion this is not the right language. Rather, we focus on data processing and data analysis, because Python is often regarded as the data science language.

Where can I get Python?

On many systems (Linux, macOS) Python is already pre-installed, partly however (macOS) in an older version. Beside the download directly from www.python.org and the manual installation of all required packages there are some preconfigured distributions. The Anaconda distribution (https://www.anaconda.com/), which contains everything you need for data science tasks, is recommended.

For this course we use Jupyter - a web-based notebook system that is also part of many distributions.

In addition to Jupyter, you can also use an IDE that supports the Jupyter notebook format, e.g.: https://code.visualstudio.com/docs/python/jupyter-support